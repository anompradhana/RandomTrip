class Region {
  final String name;
  final String province;
  final String island;
  final double latitude;
  final double longitude;
  const Region({required this.name, required this.province, required this.island, required this.latitude, required this.longitude});
}
