import 'dart:math';
import 'package:flutter/material.dart';
import 'package:flutter_map/flutter_map.dart';
import 'package:latlong2/latlong.dart';
import 'data/regions.dart';
import 'models/region.dart';

void main() => runApp(const RandomTripApp());

class RandomTripApp extends StatelessWidget {
  const RandomTripApp({super.key});
  @override
  Widget build(BuildContext context) => MaterialApp(
    debugShowCheckedModeBanner:false,
    title:'RandomTrip',
    theme:ThemeData(useMaterial3:true,colorSchemeSeed:Colors.indigo),
    home:const HomePage(),
  );
}

class HomePage extends StatefulWidget {
  const HomePage({super.key});
  @override State<HomePage> createState()=>_HomePageState();
}

class _HomePageState extends State<HomePage> {
  final mapController=MapController();
  String island='Semua Pulau', province='Semua Provinsi';
  Region? result;
  bool rolling=false;

  List<Region> get filtered=>regions.where((r)=>
    (island=='Semua Pulau'||r.island==island)&&
    (province=='Semua Provinsi'||r.province==province)).toList();

  Future<void> randomize() async {
    if(rolling||filtered.isEmpty)return;
    setState(()=>rolling=true);
    for(final z in [4.5,5.5,6.5]) {
      await Future.delayed(const Duration(milliseconds:220));
      if(!mounted)return;
      final candidates=filtered;
      final p=candidates[Random().nextInt(candidates.length)];
      mapController.move(LatLng(p.latitude,p.longitude),z);
    }
    await Future.delayed(const Duration(milliseconds:250));
    final picked=filtered[Random().nextInt(filtered.length)];
    if(!mounted)return;
    setState(()=>result=picked);
    mapController.move(LatLng(picked.latitude,picked.longitude),9);
    setState(()=>rolling=false);
  }

  @override
  Widget build(BuildContext context)=>Scaffold(
    body:Stack(children:[
      FlutterMap(
        mapController:mapController,
        options:const MapOptions(initialCenter:LatLng(-2.5,118),initialZoom:4.2),
        children:[
          TileLayer(
            urlTemplate:'https://tile.openstreetmap.org/{z}/{x}/{y}.png',
            userAgentPackageName:'com.randomtrip.app',
          ),
          if(result!=null)MarkerLayer(markers:[
            Marker(
              point:LatLng(result!.latitude,result!.longitude),
              width:70,height:70,
              child:const Icon(Icons.location_on_rounded,size:52,color:Colors.indigo),
            )
          ]),
        ],
      ),
      SafeArea(child:Column(children:[
        const SizedBox(height:12),
        Container(
          margin:const EdgeInsets.symmetric(horizontal:16),
          padding:const EdgeInsets.symmetric(horizontal:18,vertical:14),
          decoration:BoxDecoration(color:Colors.white.withOpacity(.95),borderRadius:BorderRadius.circular(22),
            boxShadow:const[BoxShadow(blurRadius:18,color:Colors.black12)]),
          child:const Row(children:[
            Icon(Icons.explore_rounded,size:28),SizedBox(width:10),
            Text('RandomTrip',style:TextStyle(fontSize:21,fontWeight:FontWeight.w800)),
          ]),
        ),
        const SizedBox(height:10),
        _filters(),
        const Spacer(),
        if(result!=null&&!rolling)_resultCard(),
        _button(),
        const SizedBox(height:18),
      ]))
    ]),
  );

  Widget _filters()=>Container(
    margin:const EdgeInsets.symmetric(horizontal:16),
    padding:const EdgeInsets.all(12),
    decoration:BoxDecoration(color:Colors.white.withOpacity(.95),borderRadius:BorderRadius.circular(20)),
    child:Row(children:[
      Expanded(child:_drop('Pulau',island,['Semua Pulau',...islands],(v)=>setState(()=>{island=v!,province='Semua Provinsi'}))),
      const SizedBox(width:8),
      Expanded(child:_drop('Provinsi',province,['Semua Provinsi',...provinces.where((p)=>island=='Semua Pulau'||regions.any((r)=>r.province==p&&r.island==island))],(v)=>setState(()=>province=v!))),
    ])
  );

  Widget _drop(String label,String value,List<String> items,ValueChanged<String?> onChanged)=>DropdownButtonFormField<String>(
    value:value,isExpanded:true,
    decoration:InputDecoration(labelText:label,border:OutlineInputBorder(borderRadius:BorderRadius.circular(14)),contentPadding:const EdgeInsets.symmetric(horizontal:12)),
    items:items.map((e)=>DropdownMenuItem(value:e,child:Text(e,overflow:TextOverflow.ellipsis))).toList(),
    onChanged:onChanged,
  );

  Widget _resultCard()=>Container(
    width:double.infinity,margin:const EdgeInsets.fromLTRB(16,0,16,12),padding:const EdgeInsets.all(20),
    decoration:BoxDecoration(color:Colors.white,borderRadius:BorderRadius.circular(26),boxShadow:const[BoxShadow(blurRadius:24,color:Colors.black26)]),
    child:Column(crossAxisAlignment:CrossAxisAlignment.start,children:[
      const Text('DESTINASI TERPILIH',style:TextStyle(fontSize:11,fontWeight:FontWeight.w800,letterSpacing:1.4)),
      const SizedBox(height:6),
      Text(result!.name,style:const TextStyle(fontSize:30,fontWeight:FontWeight.w900)),
      Text(result!.province,style:const TextStyle(fontSize:16)),
      const SizedBox(height:8),
      const Text('“Kali ini, peta yang menentukan perjalananmu.”',style:TextStyle(fontStyle:FontStyle.italic)),
    ])
  );

  Widget _button()=>Padding(
    padding:const EdgeInsets.symmetric(horizontal:16),
    child:SizedBox(width:double.infinity,height:62,
      child:FilledButton.icon(
        onPressed:rolling?null:randomize,
        icon:Icon(rolling?Icons.hourglass_top_rounded:Icons.casino_rounded,size:28),
        label:Text(rolling?'MENGACAK...':(result==null?'TENTUKAN DESTINASI':'ACAK LAGI'),
          style:const TextStyle(fontSize:17,fontWeight:FontWeight.w900)),
        style:FilledButton.styleFrom(shape:RoundedRectangleBorder(borderRadius:BorderRadius.circular(20))),
      )
    )
  );
}
