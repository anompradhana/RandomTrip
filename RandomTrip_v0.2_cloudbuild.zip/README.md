# RandomTrip v0.2

Aplikasi Android Flutter untuk menentukan kabupaten/kota tujuan liburan secara random berdasarkan filter pulau dan provinsi.

## Cloud build
Repository ini menyertakan GitHub Actions pada `.github/workflows/build-apk.yml`.
Setelah file diunggah ke branch `main`, buka tab **Actions**, pilih **Build RandomTrip APK**, lalu jalankan workflow. APK tersedia pada bagian **Artifacts**.

## Catatan
Basis wilayah pada paket ini adalah prototipe dan belum mencakup seluruh 514 kabupaten/kota. Untuk rilis publik, data administratif perlu dilengkapi dan diverifikasi.
